可以将含有3d坐标的txt格式文件转为PLY格式的QT小插件。

在目录中点击txt2ply.exe运行即可。

![image-20240809190411556](C:\Users\13920\Desktop\新建文件夹\assets\image-20240809190411556.png)

在工具中选择需要转换的文件以及保存的目录，然后点击转换。

![image-20240809190526836](C:\Users\13920\Desktop\新建文件夹\assets\image-20240809190526836.png)